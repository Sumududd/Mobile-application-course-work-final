package com.example.contactbuddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
