class Contact {
  final int? id;
  final String name;
  final String contactno;

  Contact({this.id, required this.name, required this.contactno});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'contactno': contactno,
    };
  }
}
