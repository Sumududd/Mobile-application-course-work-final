import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'contact.dart';

////////////////////////////////////// definition the DatabaseHelper class
class DatabaseHelper {
  static Database? _database;
  static const String tableName = 'contacttable';
  static const String createTableQuery = '''
    CREATE TABLE $tableName (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      contactno TEXT
    )
  ''';

  Future<Database> get database async {
    return _database ??= await initDatabase();
  }

////////////////////////////////////////////////////Intiation of the database
  Future<Database> initDatabase() async {
    try {
      String path = join(await getDatabasesPath(), 'contactdatabase.db');
      return await openDatabase(
        path,
        version: 1,
        onCreate: (db, version) {
          return db.execute(createTableQuery);
        },
      );
    } catch (e) {
      // Handle the error
      print('Error initializing database: $e');
      rethrow;
    }
  }

/////////////////////////////////////////////////////////////////////Insert data in to the database
  Future<void> insertContact(Contact contact) async {
    try {
      final Database db = await database;
      await db.insert(
        tableName,
        contact.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      // Handle the error
      print('Error inserting contact: $e');
      rethrow;
    }
  }

////////////////////////////////////////////////////////////////////////Delete contact
  Future<void> deleteContact(int id) async {
    try {
      final Database db = await database;
      await db.delete(
        tableName,
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      // Handle the error
      print('Error deleting contact: $e');
      rethrow;
    }
  }

  ///////////////////////////////////////////////////////////////////////Get all data of the data base
  Future<List<Contact>> getAllContacts() async {
    try {
      final Database db = await database;
      final List<Map<String, dynamic>> maps = await db.query(tableName);
      return List.generate(maps.length, (i) {
        return Contact(
          id: maps[i]['id'],
          name: maps[i]['name'],
          contactno: maps[i]['contactno'],
        );
      });
    } catch (e) {
      // Handle the error
      print('Error when retrieving all contacts: $e');
      return []; // Return an empty list or handle it as appropriate
    }
  }
}

///////////////////////////////////////////////////////////////////////// Data retrive form the name
Future<List<Contact>> getContactsByName(String searchname) async {
  try {
    final Database db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> maps = await db.query(
      DatabaseHelper.tableName,
      where: 'LOWER(name) = ?',
      whereArgs: [searchname.toLowerCase()],
    );
    return List.generate(maps.length, (i) {
      return Contact(
        id: maps[i]['id'],
        name: maps[i]['name'],
        contactno: maps[i]['contactno'],
      );
    });
  } catch (e) {
    // Error indication
    print('Error when retrieving contacts by name: $e');
    return []; // Return an empty list
  }
}
