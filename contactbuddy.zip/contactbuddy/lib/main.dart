import 'package:flutter/material.dart';
import 'darabasehelpar.dart';
import 'contact.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact buddy',
      home: MyHomePage(title: 'Contact Buddy'), // home screen
    );
  }
}

class MyHomePage extends StatefulWidget {
  // MyHomepage ,define a statefull widget
  final String title;

  MyHomePage({required this.title});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String name = '';
  String contactno = '';

  TextEditingController nameController = TextEditingController();
  TextEditingController contactNoController = TextEditingController();

  List<Contact> contacts = [];
  List<Contact> searchResults = [];

  @override
  void initState() {
    super.initState();
    loadContacts(); //initial contact list when the widget is created
  }

  Future<void> loadContacts() async {
    // Load all the contact from the data base
    List<Contact> allContacts = await DatabaseHelper().getAllContacts();
    setState(() {
      contacts = allContacts;
    });
  }

  void clearTextFields() {
    //Funtion definition to clear each txt feild
    nameController.clear();
    contactNoController.clear();
  }

  void showSuccessMessage() {
    //Print succussfull massage when save a contact
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Contact saved successfully'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //add Scaffold as a main structure
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: Text(widget.title),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50.0),
          child: Column(
            children: [
              Container(),
              TextField(
                // adding TextField for searching contacts by name
                cursorColor: Colors.white,
                onChanged: (searchname) async {
                  if (searchname.isEmpty) {
                    //If seach area emty print all the contact list in the data base
                    setState(() {
                      searchResults.clear();
                    });
                  } else {
                    // if serch area not emty print search contact in the list
                    List<Contact> contactsByName =
                        await getContactsByName(searchname);
                    setState(() {
                      searchResults = contactsByName;
                    });
                  }
                },
                decoration: InputDecoration(prefixIcon: Icon(Icons.search)),
                keyboardType: TextInputType.text,
              ),
            ],
          ),
        ),
      ),
      body: Form(
        //adding body to the scafolding
        key: formKey,
        child: Column(
          children: [
            TextFormField(
              // text feild form for enter contact information
              controller: nameController,
              decoration: InputDecoration(labelText: 'Name'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              },
              onSaved: (value) {
                name = value!;
              },
            ),
            TextFormField(
              controller: contactNoController,
              decoration: InputDecoration(labelText: 'Contact No'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your contact number';
                }
                return null;
              },
              onSaved: (value) {
                contactno = value!;
              },
            ),
            ElevatedButton(
              //adding button to save new contact
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  formKey.currentState!.save();
                  await DatabaseHelper()
                      .insertContact(Contact(name: name, contactno: contactno));
                  clearTextFields();
                  showSuccessMessage();
                  await loadContacts(); // Update the list after adding a contact
                }
              },
              child: Text('Save Contact'),
            ),
            SizedBox(height: 20),
            Text('Search Results:'),
            Expanded(
              child: ListView.builder(
                //diplay list of contact
                physics: AlwaysScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: searchResults.isNotEmpty
                    ? searchResults.length
                    : contacts.length,
                itemBuilder: (context, index) {
                  final contact = searchResults.isNotEmpty
                      ? searchResults[index]
                      : contacts[index];

                  return ListTile(
                    title: Text('Contact Name: ${contact.name}'),
                    subtitle: Text('Contact Number: ${contact.contactno}'),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () async {
                        await DatabaseHelper().deleteContact(contact.id!);
                        setState(() {
                          if (searchResults.isNotEmpty) {
                            searchResults.removeAt(index);
                          } else {
                            contacts.removeAt(index);
                          }
                        });
                        await loadContacts();
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
